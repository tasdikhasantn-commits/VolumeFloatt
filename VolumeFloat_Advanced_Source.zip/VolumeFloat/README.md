# VolumeFloat — Advanced Volume Mixer

Android floating volume controller with separate controls for:
- Media
- Alarm
- Ringtone / Calls
- Notifications
- System sounds

The floating panel and main screen display the developer credit: **Dev. By Tasdik Hasan**.

## Build
Open the project in Android Studio, or use the included GitHub Actions workflow to build a debug APK. See `BUILD-APK-MOBILE-BN.txt` for mobile instructions.

Note: Android manufacturers may link notification and ringtone streams together. In-call volume is subject to Android's system restrictions and call state.
