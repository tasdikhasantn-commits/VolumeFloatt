package com.example.volumefloat

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.media.AudioManager
import android.os.IBinder
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import kotlin.math.abs

class FloatingService : Service() {

    companion object {
        @Volatile
        var running = false
        private const val CHANNEL_ID = "volume_float_channel"
        private const val NOTIF_ID = 1
    }

    private lateinit var wm: WindowManager
    private lateinit var audio: AudioManager
    private var iconView: View? = null
    private var iconParams: WindowManager.LayoutParams? = null
    private var panelView: View? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        startForeground(NOTIF_ID, buildNotification())
        addFloatingIcon()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        running = false
        removePanel()
        iconView?.let { runCatching { wm.removeView(it) } }
        iconView = null
        super.onDestroy()
    }

    private fun overlayType() = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY

    private fun addFloatingIcon() {
        val view = LayoutInflater.from(this).inflate(R.layout.floating_icon, null)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = 400
        }

        val touchSlop = 10 * resources.displayMetrics.density
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var dragged = false

        view.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x
                    startY = params.y
                    touchX = event.rawX
                    touchY = event.rawY
                    dragged = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - touchX
                    val dy = event.rawY - touchY
                    if (abs(dx) > touchSlop || abs(dy) > touchSlop) dragged = true
                    if (dragged) {
                        params.x = startX + dx.toInt()
                        params.y = startY + dy.toInt()
                        runCatching { wm.updateViewLayout(view, params) }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!dragged) showPanel()
                    true
                }
                else -> false
            }
        }

        wm.addView(view, params)
        iconView = view
        iconParams = params
    }

    private fun showPanel() {
        if (panelView != null) return
        val view = LayoutInflater.from(this).inflate(R.layout.floating_panel, null)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.CENTER }

        bindStream(view, AudioManager.STREAM_MUSIC, R.id.mediaLevel, R.id.mediaUp, R.id.mediaDown)
        bindStream(view, AudioManager.STREAM_ALARM, R.id.alarmLevel, R.id.alarmUp, R.id.alarmDown)
        bindStream(view, AudioManager.STREAM_RING, R.id.ringLevel, R.id.ringUp, R.id.ringDown)
        bindStream(view, AudioManager.STREAM_NOTIFICATION, R.id.notifLevel, R.id.notifUp, R.id.notifDown)
        bindStream(view, AudioManager.STREAM_SYSTEM, R.id.systemLevel, R.id.systemUp, R.id.systemDown)

        view.findViewById<View>(R.id.btnClose).setOnClickListener { removePanel() }
        wm.addView(view, params)
        panelView = view
        iconView?.visibility = View.GONE
    }

    private fun bindStream(view: View, stream: Int, levelId: Int, upId: Int, downId: Int) {
        val level = view.findViewById<TextView>(levelId)
        updateLevel(level, stream)
        view.findViewById<View>(upId).setOnClickListener {
            audio.adjustStreamVolume(stream, AudioManager.ADJUST_RAISE, 0)
            updateLevel(level, stream)
        }
        view.findViewById<View>(downId).setOnClickListener {
            audio.adjustStreamVolume(stream, AudioManager.ADJUST_LOWER, 0)
            updateLevel(level, stream)
        }
    }

    private fun removePanel() {
        panelView?.let { runCatching { wm.removeView(it) } }
        panelView = null
        iconView?.visibility = View.VISIBLE
    }

    private fun updateLevel(tv: TextView, stream: Int) {
        val cur = audio.getStreamVolume(stream)
        val max = audio.getStreamMaxVolume(stream)
        tv.text = "${if (max > 0) cur * 100 / max else 0}%"
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Volume Float", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("Volume Float is on")
            .setContentText("Dev. By Tasdik Hasan")
            .setSmallIcon(R.drawable.ic_volume)
            .setContentIntent(open)
            .setOngoing(true)
            .build()
    }
}
